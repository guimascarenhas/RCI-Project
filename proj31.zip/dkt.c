#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include "headers.h"
#define max(A,B) ((A)>=(B)?(A):(B))
#define MAX_KEY 1000

struct sigaction act;
extern int errno;
stateInfo server;
//flag = 0 if the server is not connected to a ring
int flag;
//ekey is a flag that tells if a find is external or internal
int ekey;
//predecessor and successor's file descriptors
int pred_fd, succ_fd;
//udp_fd is a UDP server
int udp_fd;
socklen_t addrlen_udp;
struct sockaddr_in addr_udp;

int maxfd;
enum {idle, busy} state;


int main(int argc, char *argv[]){

	int fd, newfd, afd=0, counter;
	ssize_t nread;
	socklen_t addrlen;
	struct sockaddr_in addr;
	fd_set rfds;
	//a buffer for each fd
	char buffer[128]="\0" ,buffer1[128]="\0", buffer2[128]="\0", buffer3[128]="\0";
	int fullpred=1, fullsucc=1, fullafd=1;

	if(argc < 3){
		printf("Missing arguments when calling dkt\n");
		exit(1);
	}

	//initializes variables and sigaction
	initAll(argv[1], argv[2]);

	//create TCP and UDP sockets
	fd=createSocketTCP_server(server.nodeTCP);
	udp_fd=createSocketUDP_server(server.nodeTCP);


	while(1){
		FD_ZERO(&rfds);
		FD_SET(0,&rfds);
		FD_SET(fd,&rfds);
		FD_SET(udp_fd,&rfds);

		//sets file descriptors (fds) if they are being used
		if(pred_fd>0) FD_SET(pred_fd,&rfds);
		if(succ_fd>0) FD_SET(succ_fd,&rfds);
		if(state==busy)	FD_SET(afd,&rfds);

		//blocks until any input from one of the fds is ready
		counter=select(maxfd+1, &rfds, (fd_set*)NULL, (fd_set*)NULL, (struct timeval *)NULL);
		if(counter<=0) exit(1);

		//accepts connections when server is ready (flag=1)
		if(flag == 1 && FD_ISSET(fd,&rfds)){
			addrlen=sizeof(addr);
			if((newfd=accept(fd, (struct sockaddr*)&addr, &addrlen))==-1) exit(1);
			switch(state){
				case idle:	afd=newfd;
							state=busy;
							maxfd=max(maxfd,afd);
							break;

				case busy:	write(newfd, "Busy\n", 5);
							close(newfd);
			}
		}

		//reads input from the connecting server
		if(state == busy && FD_ISSET(afd,&rfds)){
			//checks is the full message was received and puts it together if not
			readTCP(afd, buffer1, &fullafd);
			if(fullafd==1){
				//if the server has the full message it can handle it
				if(messageHandler(afd, buffer1)){
					state=idle;
					cleanBuffer(buffer1);
				}
			}
			else{
				close(afd);
				state = idle;
			}
		}

		//reads input from keyboard
		else if(FD_ISSET(0,&rfds)){
			if(UserInput()) {
				printf("Invalid command\n");
			}
		}

		//reads input from successor
		else if(succ_fd>0 && FD_ISSET(succ_fd,&rfds)){
			//checks is the full message was received and puts it together if not
			readTCP(succ_fd, buffer2, &fullsucc);
			if(fullsucc==1){
				//if the server has the full message it can handle it
				succMessageHandler(buffer2);
				cleanBuffer(buffer2);
			}
			else if(fullsucc==-1){
				succLeft();
				fullsucc=1;
			}
		}

		//reads input from predecessor
		else if(pred_fd>0 && FD_ISSET(pred_fd,&rfds)){
			//checks is the full message was received and puts it together if not
			readTCP(pred_fd, buffer3, &fullpred);
			if(fullpred==1){
				//if the server has the full message it can handle it
				predMessageHandler(buffer3);
				cleanBuffer(buffer3);
			}
		}
		//receives UDP message if the server is connected to a ring
		else if(udp_fd>0 && FD_ISSET(udp_fd,&rfds)){

			addrlen_udp=sizeof(addr_udp);
			nread= recvfrom (udp_fd,buffer,128,0,(struct sockaddr*)&addr_udp,&addrlen_udp);
			if(nread==-1)/*error*/exit(1);

			UDPMessageHandler(buffer);

		}
	}
	exit(0);
}

void initAll(char *ip, char* p){

	//server is not connected in the beginning of the program
	flag=0;
	ekey=0;

	//fds not in use yet
	pred_fd=-1;
	succ_fd=-1;
	udp_fd=-1;

	//stores host info
	sprintf(server.nodeIP,"%s", ip);
	server.nodeTCP=atoi(p);
	server.node_key=-1;

	//server is available
	state = idle;

	//tells system to ignore SIGPIPE
	memset(&act,0,sizeof(act));
	act.sa_handler=SIG_IGN;
	if(sigaction(SIGPIPE, &act, NULL)==-1) exit(1);

	return;
}

//handles reecived UDP messages
void UDPMessageHandler(char *buffer){
	int i=0;
	char option[10];

	if(!sscanf(buffer, " %s", option)) return ;

	if(strcmp(option, "EFND")==0){
		if(sscanf(buffer, "%s %d", option,&i)==2){
			//An external find was requested so ekey is set to 1
			ekey=1;
			//Requests a search for the key
			find(i,server.node_key,server.nodeIP,server.nodeTCP);
		}
	}
	return;
}

//calculates distance between keys k and l
int dist(int k, int l){
	int d=0;
	if(k>l){
		d=MAX_KEY-(k-l);
	}
	else{
		d=l-k;
	}

	return d;
}

void succLeft(){
	close(succ_fd);
	succ_fd=createSocket(server.succ2IP, server.succ2TCP);
	server.succ_key=server.succ2_key;
	strcpy(server.succIP, server.succ2IP);
	server.succTCP=server.succ2TCP;
	sendSUCCCONF(succ_fd);
	sendSUCC(pred_fd);
}

void predMessageHandler(char *buffer){
	int k=0,i=0,port=0;
	char option[10],ip[9]="\n";

	if(!sscanf(buffer, " %s", option)) return ;

	if(strcmp(option, "FND")==0){
		if(sscanf(buffer, "%s %d %d %s %d", option, &k, &i, ip, &port)==5){
				find(k,i,ip,port);
		}

	}
}

//handles messages that come from the successor
void succMessageHandler(char *buffer){

	char option[10];


	if(!sscanf(buffer, " %s", option)) return;

	//if SUCC is received it means the server has to update its second successor
	if(strcmp(option,"SUCC")==0){
		sscanf(buffer,"%s %d %s %d", option, &server.succ2_key,server.succ2IP,&server.succ2TCP);
	}
	//if NEW is received it means that a server is connecting between the current server and the successor
	else if(strcmp(option,"NEW")==0){

		//the successor becomes the second successor
		server.succ2_key=server.succ_key;
		server.succ2TCP=server.succTCP;
		strcpy(server.succ2IP, server.succIP);


		sscanf(buffer,"%s %d %s %d", option, &server.succ_key,server.succIP,&server.succTCP);
		close(succ_fd);
		succ_fd=createSocket(server.succIP,server.succTCP);
		sendSUCCCONF(succ_fd);
		sendSUCC(pred_fd);
	}

	return;
}

//handles messages that come from afd. if it's not a valid message it ends the session with afd
int messageHandler(int afd, char *buffer){

	int k=0,i=0,port=0, n=0;
	char option[10],ip[9]="\n";
	char text[128];


	if(!sscanf(buffer, " %s", option)) return 1;

	if(strcmp(option,"NEW")==0){
		{
			//if server is alone in the ring it must allow the connection by the new server and connect itself to the entering server
			if(server.node_key == server.succ_key && sscanf(buffer,"%s %d %s %d", option,&server.succ_key,server.succIP,&server.succTCP)==4){
				pred_fd=afd;
				succ_fd=createSocket(server.succIP, server.succTCP);
				sendSUCCCONF(succ_fd);
				return 1;
			}
			//makes the entering server the new predecessor
			else{
				//sends info about the successor to the new predecessor
				sendSUCC(afd);

				//informs the old predecessor that a server is connecting
				sendBuffer(pred_fd, buffer);

				//ends session with the old predecessor
				close(pred_fd);

				//updates the predecessor's fd
				pred_fd=afd;
				return 1;
			}
		}

	}

	//updates the predecessor
	else if(strcmp(option, "SUCCCONF")==0){
		//if the server already has a predecessor it must end the session
		if(pred_fd>0) close(pred_fd);
		pred_fd=afd;
		sendSUCC(pred_fd);
		return 1;
	}
	//prints message telling the key was found
	else if(strcmp(option, "KEY")==0){
		if(sscanf(buffer, "%s %d %d %s %d", option, &k, &i, ip, &port)==5){
				printf("KEY %d found:\n",k);
				printf("\t \t Server: %d\n\t \t IP: %s\n\t \t Port: %d\n", i, ip, port);

				//if the find was an external request
				if(ekey==1){
					//formats EKEY message and sends it to the UDP client who requested the search
					sprintf(text,"EKEY %d %d %s %d\n",k,i,ip, port);
					n=sendto(udp_fd,text,strlen(text),0,(struct sockaddr*)&addr_udp,addrlen_udp);
					if(n==-1) exit(1);

					//resets flag now that the external find is done
					ekey=0;
				}
				return 1;
		}
	}

	return 0;
}

//sends buffer to the provided fd
void sendBuffer(int fd, char *buffer){
	ssize_t n;

	n=write(fd, buffer, strlen(buffer));
	if(n==-1)/*error*/exit(1);
}

//sends info about the successor to the provided fd
void sendSUCC(int fd){
	char text[128];

	//formats SUCC message and sends it
	sprintf(text,"SUCC %d %s %d \n", server.succ_key, server.succIP, server.succTCP);
	sendBuffer(fd, text);

	return;
}

//sends SUCCONF message to the provided fd
void sendSUCCCONF(int fd){
	char text[9]= "SUCCCONF\n";

	sendBuffer(fd, text);
	return;
}

//reads the input and checks if the command is one of the predefined, returns 1 if the command is invalid (ex: arguments missing)
int UserInput(){

	int i=-1, succi=0, succ_port=0,k=0, boot=0,boot_port=0;
	char option[10]="\0", input[128]="\0", succIP[9]="\n",bootIP[9]="\n";

	if(fgets(input, 128, stdin)==NULL){
		return 1;
	}

	if(!sscanf(input, " %s", option)) return 1;


	if(strcmp(option, "new")==0){

		//new can only be called if the server is not in a ring
		if(flag==0){
			if(sscanf(input, " %s %d", option, &i)==2 && i<MAX_KEY && i>=0){
				CreateRing(i);
				flag=1;
				return 0;
			}
			else return 1;
		}

		else{
			printf("new has already been called\n");
			return 0;
		}


	}

	else if(strcmp(option, "entry")==0){

		if(sscanf(input, " %s %d %d %s %d", option,&i,&boot,bootIP,&boot_port )==5 && i<MAX_KEY && boot<MAX_KEY && i>=0 && boot>=0){
				entry(i,boot,bootIP,boot_port);
				return 0;
		}
		return 1;
	}

	else if(strcmp(option, "sentry")==0){

		if(sscanf(input, " %s %d %d %s %d", option, &i ,&succi, succIP, &succ_port)==5 && i<MAX_KEY && i>=0 && i!=succi){
				sentry(i, succi, succIP, succ_port);
				return 0;
		}
		return 1;
	}

	else if(strcmp(option, "leave")==0){
		leave();
		return 0;
	}

	else if(strcmp(option, "show")==0){
		ShowState();
		return 0;
	}

	else if(flag == 1 && strcmp(option, "find")==0){
		if(sscanf(input, " %s %d", option, &k)==2 && k<MAX_KEY && k>=0){
				find(k,server.node_key,server.nodeIP,server.nodeTCP);
				return 0;
		}
		return 1;
	}

	else if(strcmp(option, "exit")==0){
		exit(1);
	}


	return 1;
}

//creates a new ring
void CreateRing(int i){

	//initializes the successor and the second successor with the current server info (key, IP and port)
	server.node_key = i;

	server.succ_key = i;
	server.succTCP= server.nodeTCP;
	strcpy(server.succIP, server.nodeIP);

	server.succ2_key = i;
	server.succ2TCP= server.nodeTCP;
	strcpy(server.succ2IP, server.nodeIP);

	return;
}

//shows info about current server, successor and second successor
void ShowState(){
	printf("\nState info:\n");

	if(server.node_key == -1){
		printf("\t \t node IP and Port: %s :%d\n", server.nodeIP, server.nodeTCP);
		return;
	}
	else{
		printf("\t\t \tkey: %d\n", server.node_key);
		printf("\t   current:     IP: %s\n", server.nodeIP);
		printf("\t\t \tport: %d\n\n", server.nodeTCP);
		printf("\t\t \tkey: %d\n", server.succ_key);
		printf("\t  successor:    IP: %s\n", server.succIP);
		printf("\t\t \tport: %d\n\n", server.succTCP);
		printf("\t\t \tkey: %d\n", server.succ2_key);
		printf("\t2nd successor:  IP: %s\n", server.succ2IP);
		printf("\t\t \tport: %d\n\n", server.succ2TCP);
	}
	return;
}

//resets variable values to default
void resetInfo(){

	server.node_key=-1;

	server.succ_key=server.node_key;
	strcpy(server.succIP, server.nodeIP);
	server.succTCP=server.nodeTCP;

	server.succ2_key=server.node_key;
	strcpy(server.succ2IP, server.nodeIP);
	server.succ2TCP=server.nodeTCP;

	pred_fd=-1;
	succ_fd=-1;

	flag=0;

	return;
}

//stores the info provided in the sentry command
void storeInfo(int i, int succi, char *succIP, int succ_port){

	server.node_key = i;

	//stores successor's info
	server.succ_key = succi;
	strcpy(server.succIP, succIP);
	server.succTCP = succ_port;

	//the second successor is initialized with the current server values
	server.succ2_key = i;
	strcpy(server.succ2IP, server.nodeIP);
	server.succ2TCP = server.nodeTCP;
	return;
}

//server leaves the ring
void leave(){

	if(flag == 0){
		printf("Server is not connected to a ring yet\n");
		printf("If you want to close use 'exit'\n");
		return;
	}
	else{
		//close all connections to the ring
		close(pred_fd);
		close(succ_fd);
		resetInfo();
	}
}

//connects server to a specific place in the ring
void sentry(int i, int succi, char* succIP, int succ_port){

	int fd;
	char text[128];

	//creates socket to connect to the successor
	fd=createSocket(succIP, succ_port);
	succ_fd=fd;

	//saves the info provided in the sentry command
	storeInfo(i, succi, succIP, succ_port);

	//formats the NEW message and sends it to the successor
	sprintf(text,"NEW %d %s %d \n",i, server.nodeIP, server.nodeTCP);
	sendBuffer(succ_fd, text);

	//server is connected from now on
	flag=1;

	return;
}

int createSocketTCP_server(int p){

	int fd;
	struct addrinfo hints, *res;
	char port[9];

	//creates TCP socket for listening
	fd=socket(AF_INET, SOCK_STREAM, 0);
	if(fd==-1){
		printf("Could not create socket\n");
		exit(1);
	}

	//Fills info about the socket
	memset(&hints, 0, sizeof(hints));
	hints.ai_family=AF_INET;
	hints.ai_socktype=SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;

	//Converts port to string type
	sprintf(port,"%d",p);

	getaddrinfo(NULL, port, &hints, &res);
	if(errno!= 0){
		fprintf(stderr, "error %s\n", gai_strerror(errno));
		exit(1);
	}

	errno=bind(fd, res->ai_addr, res->ai_addrlen);
	if(errno==-1){
		printf("Could not bind socket\n");
		exit(1);
	}

	if(listen(fd,5)==-1){
		perror("Error ");
		exit(1);
	}

	maxfd=fd;

	free(res);
	return fd;
}

//creates a TCP socket and connects with another server. returns the file descriptor
int createSocket(char *ip, int p){

	struct addrinfo hints, *res;
	char port[9];
	int n;

	//creates TCP socket
	int fd=socket(AF_INET,SOCK_STREAM,0);//TCP socket
	if (fd==-1){printf("couldn't create socket\n"); exit(1);} //error

	//gives info about the socket
	memset(&hints, 0, sizeof(hints));
	hints.ai_family=AF_INET;
	hints.ai_socktype=SOCK_STREAM;
	hints.ai_flags = AI_PASSIVE;

	//converts port into string
	sprintf(port,"%d",p);

	errno=getaddrinfo(ip,port,&hints,&res) ;
	if(errno!=0) /*error*/ exit(1);

	//establishes connection with another server
	n=connect(fd,res->ai_addr,res->ai_addrlen);
	if(n==-1)/*error*/exit(1);

	maxfd=max(maxfd,fd);

	free(res);
	return fd;
}

//creates a UDP server and returns the file descriptor
int createSocketUDP_server(int p){

	int fd;
	struct addrinfo hints,*res;
	char port[9];

	fd=socket(AF_INET,SOCK_DGRAM,0); //UDP socket
	if(fd==-1) /*error*/exit(1);

	memset(&hints,0,sizeof(hints));
	hints.ai_family=AF_INET; // IPv4
	hints.ai_socktype=SOCK_DGRAM; // UDP socket
	hints.ai_flags=AI_PASSIVE;

	sprintf(port,"%d",p);

	errno= getaddrinfo (NULL,port,&hints,&res);
	if(errno!= 0){
		fprintf(stderr, "error %s\n", gai_strerror(errno));
		exit(1);
	}


	errno=bind(fd,res->ai_addr, res->ai_addrlen);
	if(errno==-1){
		printf("Could not bind socket\n");
		exit(1);
	}


	maxfd=max(fd,maxfd);

	free(res);
	return fd;
}

void find(int k,int i,char *ip,int port){
	char text[128]="\n";
	int fd=0,n;

	//if the server is alone in the ring it has all the keys
	if(server.node_key==server.succ_key){
		printf("KEY %d found:\n",k);
		printf("\t \t Server: %d\n\t \t IP: %s\n\t \t Port: %d\n",server.node_key,server.nodeIP,server.nodeTCP);
		if(ekey==1){
			//formats EKEY message and sends it to the UDP client who requested the search
			sprintf(text,"EKEY %d %d %s %d\n",k,i,ip, port);

			n=sendto(udp_fd,text,strlen(text),0,(struct sockaddr*)&addr_udp,addrlen_udp);
			if(n==-1) exit(1);

			//external find is done
			ekey=0;
		}
		return;
	}

	//checks if the key is closer to the successor
	if(dist(k,server.succ_key)> dist(k,server.node_key)){

		//formats find message
		sprintf(text,"FND %d %d %s %d\n",k,i,ip,port);

		//sends the find request to the successor
		sendBuffer(succ_fd, text);
		return;
	}

	else{
		//formats the message that tells the key was found
		sprintf(text,"KEY %d %d %s %d\n",k,server.succ_key,server.succIP,server.succTCP);

		//creates socket to communicate with the server that requested the search and sends it a message
		fd=createSocket(ip, port);
		sendBuffer(fd, text);

		close(fd);
		return;
	}
}

void entry(int i, int boot, char* bootIP, int boot_port){

	ssize_t n;
	socklen_t addrlen;
	struct addrinfo hints,*res;
	struct sockaddr_in addr;
	char buffer[128], text[128],option[9]="\n",ip[9]="\n";
	int k=0,porto=0;
	int u_fd=0;
	char port[9];

	//creates UDP client socket to send an external find to the ring
	u_fd=socket(AF_INET,SOCK_DGRAM,0);	//UDP socket
	if (u_fd==-1){printf("couldn't create socket\n"); exit(1);} //error

	//gives info about the socket
	memset(&hints, 0, sizeof(hints));
	hints.ai_family=AF_INET;
	hints.ai_socktype=SOCK_DGRAM;

	//converts boot_port to a string
	sprintf(port,"%d",boot_port);

	errno=getaddrinfo(bootIP,port,&hints,&res);
	if(errno!=0) /*error*/ exit(1);

	//formats EFND message and sends it to a UDP server in a ring
	sprintf(text,"EFND %d\n",i);
	n=sendto(u_fd,text,strlen(text),0,res->ai_addr,res->ai_addrlen);
	if(n==-1) /*error*/ exit(1);

	addrlen=sizeof(addr);

	//waits for the boot server's response
	n=recvfrom (u_fd,buffer,128,0,(struct sockaddr*)&addr,&addrlen);
	if(n==-1) exit(1);

	//processes the boot server's response
	if(sscanf(buffer, "%s %d %d %s %d", option, &i, &k, ip, &porto)==5){
		if(k==i){
			//the requested key is in use
			printf("Server %d already exists in the ring\n", k);
		}
		else{
			//connect to a server in the ring
			sentry(i,k,ip,porto);
		}
	}

	freeaddrinfo(res);
	close (u_fd);
}

//sets the provided buffer to '\0'
void cleanBuffer(char* buff){
	for(int i=0; i<strlen(buff); i++){
		buff[i]='\0';
	}
}

//reads the available content from a given fd
void readTCP(int fd, char* buff, int* full){

	ssize_t n;
	char temp[128];
	int i=0;
	if((n=read(fd,temp,128))!=0){
		if(n==-1) exit(1);

		//if the last message was fully received or if its the first message, copies temp to buff
		if(*full==1){
			strcpy(buff,temp);
		}
		else{
			//if *full is different from 1 it means that the message wasnt received all together and we have to concatenate the strings
			strcat(buff, temp);
		}
		//checks if the message was fully received (search for '\n')
		for(i=0; i<strlen(temp); i++){
			if(strchr(temp, '\n')!=NULL){
				*full=1;
				return;
			}
		}
		*full=0;
	}else *full=-1;	//a server has left
}
